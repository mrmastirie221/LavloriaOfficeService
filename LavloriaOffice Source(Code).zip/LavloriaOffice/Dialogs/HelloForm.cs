﻿using System;
using System.Media;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;

namespace LavloriaOffice.Dialogs
{
    public partial class HelloForm : Form
    {
        public HelloForm()
        {
            InitializeComponent();
        }

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void rjButton2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void HelloForm_Load(object sender, EventArgs e)
        {
            try
            {
                SoundPlayer startSound = new SoundPlayer(@"Data\sounds\Sound_NewCall.wav");
                startSound.Play();
            }
            catch 
            {
            }
        }

        private void rjButton1_Click(object sender, EventArgs e)
        {
            if (rjTextBox1.Texts == "")
            {
                MessageBox.Show("Вы не указали имя.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                using (RegistryKey key = Registry.CurrentUser.CreateSubKey(@"SoftWare\Lavloria\LavloriaOffice\Settings"))
                {
                    key.SetValue("username", rjTextBox1.Texts);
                }
                Close();
            }
        }
    }
}
