﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Microsoft.Win32;
using System.Windows.Forms;
using System.Drawing.Printing;

namespace LavloriaOffice.LDE
{
    public partial class LDEForm : Form
    {
        public LDEForm()
        {
            InitializeComponent();
        }

        string filepath = "";
        string docname = "";

        private void LDEForm_Load(object sender, EventArgs e)
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SoftWare\Lavloria\LavloriaOffice\LDE"))
                {
                    filepath = key.GetValue("backpath").ToString();
                    docname = key.GetValue("backname").ToString();
                }
                
                richTextBox1.LoadFile(filepath);

            }
            catch (Exception ex)
            {
                using (StreamWriter writer = new StreamWriter(@"logs\applog.txt", true))
                {
                    writer.WriteLine("Error: " + "\n" + ex);
                }
            }
        }

        private void открытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openFileDialog2.Filter = "LDE documents(*.ldoc)|*.ldoc";
            if (openFileDialog2.ShowDialog() == DialogResult.Cancel)
                return;
            richTextBox1.LoadFile(openFileDialog2.FileName);
        }

        private void сохранитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "doc file(*.ldoc)|*.ldoc";
            saveFileDialog1.Title = "Сохранение";
            saveFileDialog1.FileName = docname;
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                richTextBox1.SaveFile(saveFileDialog1.FileName);
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.png; *.bmp)|*.jpg; *.jpeg; *.gif; *.png; *.bmp";
            if (openFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;      
            Clipboard.SetImage(Image.FromFile(openFileDialog1.FileName));
            richTextBox1.Paste();
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            richTextBox1.SelectionColor = colorDialog1.Color;
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            if (fontDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            richTextBox1.SelectionFont = fontDialog1.Font;
        }

        private void сохранитьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            richTextBox1.SaveFile(filepath);
        }

        private void распечататьДокументToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            PrintDocument documentToPrint = new PrintDocument();
            printDialog.Document = documentToPrint;

            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                StringReader reader = new StringReader(richTextBox1.Text);
                documentToPrint.PrintPage += new PrintPageEventHandler(DocumentToPrint_PrintPage);
                documentToPrint.Print();
            }
        }

        private void DocumentToPrint_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            StringReader reader = new StringReader(richTextBox1.Text);
            float LinesPerPage = 0;
            float YPosition = 0;
            int Count = 0;
            float LeftMargin = e.MarginBounds.Left;
            float TopMargin = e.MarginBounds.Top;
            string Line = null;
            Font PrintFont = this.richTextBox1.Font;
            SolidBrush PrintBrush = new SolidBrush(Color.Black);

            LinesPerPage = e.MarginBounds.Height / PrintFont.GetHeight(e.Graphics);

            while (Count < LinesPerPage && ((Line = reader.ReadLine()) != null))
            {
                YPosition = TopMargin + (Count * PrintFont.GetHeight(e.Graphics));
                e.Graphics.DrawString(Line, PrintFont, PrintBrush, LeftMargin, YPosition, new StringFormat());
                Count++;
            }

            if (Line != null)
            {
                e.HasMorePages = true;
            }
            else
            {
                e.HasMorePages = false;
            }
            PrintBrush.Dispose();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InfoLDEForm infoLDEForm = new InfoLDEForm();
            infoLDEForm.Show();
        }

        private void документацияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (RegistryKey key = Registry.CurrentUser.CreateSubKey(@"SoftWare\Lavloria\LavloriaOffice\LDE"))
            {
                key.SetValue("backpath", @"Data\documents\OfficeManual.ldoc");
            }

            LDEForm LDEform = new LDEForm();
            LDEform.Show();
            Close();
        }

        private void новыйДокументToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CreateProjectForm cpf = new CreateProjectForm();
            cpf.Show();

            Close();
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            if (filepath == "")
            {
                saveFileDialog1.Filter = "doc file(*.ldoc)|*.ldoc";
                saveFileDialog1.Title = "Сохранение";
                saveFileDialog1.FileName = docname;
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                    richTextBox1.SaveFile(saveFileDialog1.FileName);
            }

            richTextBox1.SaveFile(filepath);
        }
    }
}