﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using Microsoft.Win32;
using System.Windows.Forms;

namespace LavloriaOffice.ToolForms
{
    public partial class SelectToolForm : Form
    {
        public SelectToolForm()
        {
            InitializeComponent();
        }

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        private void iconPictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            Calendar calendar = new Calendar();
            calendar.Show();

            Close();
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            CalcForm clcform = new CalcForm();
            clcform.Show();

            Close();
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "PDF Документ(*.pdf)|*.pdf";

            if (openFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;

            using (RegistryKey key = Registry.CurrentUser.CreateSubKey(@"SoftWare\Lavloria\LavloriaOffice\Settings"))
            {
                key.SetValue("temppdf", openFileDialog1.FileName);
            }

            PDFreaderForm pdfrf = new PDFreaderForm();
            pdfrf.Show();

            Close();
        }

    }
}
