﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Linq;
using System.Text;
using iTextSharp;
using System.Threading.Tasks;
using Microsoft.Win32;
using System.Windows.Forms;
using iTextSharp.text.pdf.parser;

namespace LavloriaOffice.ToolForms
{
    public partial class PDFreaderForm : Form
    {
        public PDFreaderForm()
        {
            InitializeComponent();
        }

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        string filepdfpath = "";


        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void iconPictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void PDFreaderForm_Load(object sender, EventArgs e)
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SoftWare\Lavloria\LavloriaOffice\Settings"))
                {
                    filepdfpath = key.GetValue("temppdf").ToString();
                }

                iTextSharp.text.pdf.PdfReader reader = new iTextSharp.text.pdf.PdfReader(filepdfpath);
                StringBuilder sb = new StringBuilder();

                for (int i = 1; i <= reader.NumberOfPages; i++)
                {
                    sb.Append(PdfTextExtractor.GetTextFromPage(reader, i));
                }
                richTextBox1.Text = sb.ToString();
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
