﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LavloriaOffice.ToolForms
{
    public partial class CalcForm : Form
    {
        public CalcForm()
        {
            InitializeComponent();
        }

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void iconPictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void rjButton1_Click(object sender, EventArgs e)
        {
            if (rjTextBox1.Texts == "" || rjTextBox2.Texts == "" || comboBox1.Text == "")
            {
                MessageBox.Show("Вы не заполнили все поля.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int a = Convert.ToInt32(rjTextBox1.Texts);
            int b = Convert.ToInt32(rjTextBox2.Texts);
            string opr = comboBox1.Text;

            if (rjTextBox2.Texts == "0" && comboBox1.Text == "/")
            {
                MessageBox.Show("На ноль делить нельзя :(", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            switch (opr)
            {
                case "+":
                    rjTextBox3.Texts = Convert.ToInt32(a + b).ToString();
                    break;
                case "-":
                    rjTextBox3.Texts = Convert.ToInt32(a - b).ToString();
                    break;
                case "*":
                    rjTextBox3.Texts = Convert.ToInt32(a * b).ToString();
                    break;
                case "/":
                    rjTextBox3.Texts = Convert.ToInt32(a / b).ToString();
                    break;
            }
        }
    }
}
