﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.IO;
using LavloriaOffice.LDE;
using Microsoft.Win32;

namespace LavloriaOffice
{
    public partial class CreateProjectForm : Form
    {
        public CreateProjectForm()
        {
            InitializeComponent();
        }

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        string doctype = "";


        private void rjButton1_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "LDE documents(*.ldoc)|*.ldoc";
            saveFileDialog1.FileName = rjTextBox1.Texts;

            if (saveFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            rjTextBox2.Texts = saveFileDialog1.FileName;
        }

        private void rjButton2_Click(object sender, EventArgs e)
        {
            if (rjTextBox1.Texts == "" || rjTextBox2.Texts == "" || doctype == "")
            {
                MessageBox.Show("Вознилка ошибка! Возможны следующие причины: \n 1. Не заполнены все поля \n 2. Не выбран тип документа",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (RegistryKey key = Registry.CurrentUser.CreateSubKey(@"SoftWare\Lavloria\LavloriaOffice\LDE"))
            {
                key.SetValue("backname", rjTextBox1.Texts);
                key.SetValue("backpath", rjTextBox2.Texts);
                key.SetValue("backtype", doctype);
            }

            LDEForm lde = new LDEForm();
            lde.Show();

            Close();
        }

        private void rjButton3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void rjRadioButton1_CheckedChanged(object sender, EventArgs e)
        {
            doctype = "ldoc";
            label3.Text = "Выбран";
        }
    }
}