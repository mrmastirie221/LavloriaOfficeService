﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using LavloriaOffice.ToolForms;
using System.Linq;
using System.Runtime.InteropServices;
using LavloriaOffice.Other.JSON;
using System.Text;
using System.Net;
using Microsoft.Win32;
using LavloriaOffice.Other;
using System.Threading.Tasks;
using System.Windows.Forms;
using LavloriaOffice.Dialogs;
using LavloriaOffice.LDE;
using Newtonsoft.Json;
using System.IO;

namespace LavloriaOffice
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        private void iconPictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SoftWare\Lavloria\LavloriaOffice\Settings"))
            {
                string name = "";

                try
                {
                    name = key.GetValue("username").ToString();
                }
                catch{}

                if (name == "")
                {
                    label3.Text = "Приветствуем, User!";
                    HelloForm form = new HelloForm();
                    form.Show();
                }
                else
                {
                    label3.Text = $"Приветствуем, {name}!";
                }
            }

            try
            { 
                using (RegistryKey keyrs = Registry.CurrentUser.OpenSubKey(@"SoftWare\Lavloria\LavloriaOffice\LDE"))
                {
                    iconButton4.Text = keyrs?.GetValue("backname").ToString();
                }

                if (iconButton4.Text == "")
                {
                    iconButton4.Text = "Последних нету...";
                }
            }
            catch { };

            using (WebClient wb = new WebClient())
            {
                wb.DownloadFile("https://raw.githubusercontent.com/mrmastirie221/LavloriaOfficeService/main/update/updateinfo.json", @"Data\settings\updateinfo.json");
            }


            string temp1 = File.ReadAllText(@"Data\settings\dataversion.json");
            string temp2 = File.ReadAllText(@"Data\settings\updateinfo.json");

            var data = JsonConvert.DeserializeObject<MyVersionJson>(temp1);
            var updateinf = JsonConvert.DeserializeObject<UpdateVersionJson>(temp2);

            if (data.MyVersion != updateinf.ActVersion)
            {
                MessageBox.Show($"Доступно обновление {updateinf.ActVersion} {updateinf.ActNameVersion}. \nДля загрузки перейдите в центр обновления.",
                    $"Обновление {updateinf.ActVersion}", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (data.MyVersion == updateinf.ActVersion)
            {

            }
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            CreateProjectForm frmproj = new CreateProjectForm();
            frmproj.Show();
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            if (iconButton4.Text == "Последних нету...")
                return;

            LDEForm lde = new LDEForm();
            lde.Show();
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "LDE documents(*.ldoc)|*.ldoc";
            if (openFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;

            using (RegistryKey key = Registry.CurrentUser.CreateSubKey(@"SoftWare\Lavloria\LavloriaOffice\LDE"))
            {
                key.SetValue("backname", "");
                key.SetValue("backpath", openFileDialog1.FileName);
                key.SetValue("backtype", "");
            }

            LDEForm lde = new LDEForm();
            lde.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LDEForm lde = new LDEForm();
            lde.Show();
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            SelectToolForm stf = new SelectToolForm();
            stf.Show();
        }

        private void iconButton5_Click(object sender, EventArgs e)
        {
            UpdateCenterForm upf = new UpdateCenterForm();
            upf.Show();
        }
    }
}
