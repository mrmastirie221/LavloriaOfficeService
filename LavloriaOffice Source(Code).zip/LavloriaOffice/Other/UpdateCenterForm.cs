﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using Newtonsoft.Json;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LavloriaOffice.Other.JSON;

namespace LavloriaOffice.Other
{
    public partial class UpdateCenterForm : Form
    {
        public UpdateCenterForm()
        {
            InitializeComponent();
        }

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        private void iconPictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void rjButton2_Click(object sender, EventArgs e)
        {
            try
            {
                if (rjButton2.Text == "Скачать")
                {
                    string temp3 = File.ReadAllText(@"Data\settings\updateinfo.json");
                    var updatesin = JsonConvert.DeserializeObject<UpdateVersionJson>(temp3);

                    var objup = new MyVersionJson()
                    {
                        MyVersion = updatesin.ActVersion,
                        NameOfVersion = updatesin.ActNameVersion,
                    };

                    File.WriteAllText(@"Data\settings\dataversion.json", JsonConvert.SerializeObject(objup));

                    Process.Start("AutoUpdateOffice.exe");
                    
                    Application.Exit();
                }

                using (WebClient wb = new WebClient())
                {
                    wb.DownloadFile("https://raw.githubusercontent.com/mrmastirie221/LavloriaOfficeService/main/update/updateinfo.json", @"Data\settings\updateinfo.json");
                }

                string temp1 = File.ReadAllText(@"Data\settings\dataversion.json");
                string temp2 = File.ReadAllText(@"Data\settings\updateinfo.json");

                var data = JsonConvert.DeserializeObject<MyVersionJson>(temp1);
                var updateinf = JsonConvert.DeserializeObject<UpdateVersionJson>(temp2);

                if (data.MyVersion != updateinf.ActVersion)
                {
                    label3.Text = $"Обнаружено обновление {updateinf.ActVersion}, скачайте обновление";
                    rjButton2.Text = "Скачать";
                }
                else if (data.MyVersion == updateinf.ActVersion)
                {
                    label3.Text = "У вас установлена актуальная версия.";
                    return;
                }
            }
            catch { }

        }

        private void UpdateCenterForm_Load(object sender, EventArgs e)
        {
            string temp1 = File.ReadAllText(@"Data\settings\dataversion.json");
            var obj = JsonConvert.DeserializeObject<MyVersionJson>(temp1);

            label2.Text = $"Ваша версия: {obj.MyVersion} | {obj.NameOfVersion}";

            using (WebClient wc = new WebClient())
            {
                wc.DownloadFile("https://raw.githubusercontent.com/mrmastirie221/LavloriaOfficeService/main/update/news.txt", @"Data\settings\news.txt");
            }

            label4.Text = File.ReadAllText(@"Data\settings\news.txt");
        }

        private void iconPictureBox1_Click_1(object sender, EventArgs e)
        {
            Close();
        }
    }
}
