﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LavloriaOffice.Other.JSON
{
    internal class MyVersionJson
    {
        public string MyVersion { get; set; }
        public string NameOfVersion { get; set; }
    }
}
