﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LavloriaOffice.Other.JSON
{
    public class UpdateVersionJson
    {
        public string ActVersion { get; set; }
        public string ActNameVersion { get; set; }
    }
}
